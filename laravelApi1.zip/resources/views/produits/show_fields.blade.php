<!-- Nomprod Field -->
<div class="form-group">
    {!! Form::label('nomprod', 'Nomprod:') !!}
    <p>{!! $produit->nomprod !!}</p>
</div>

<!-- Imageprod Field -->
<div class="form-group">
    {!! Form::label('imageprod', 'Imageprod:') !!}
    <p>{!! $produit->imageprod !!}</p>
</div>

<!-- Prix Field -->
<div class="form-group">
    {!! Form::label('prix', 'Prix:') !!}
    <p>{!! $produit->prix !!}</p>
</div>

<!-- Quantite Field -->
<div class="form-group">
    {!! Form::label('quantite', 'Quantite:') !!}
    <p>{!! $produit->quantite !!}</p>
</div>

<!-- Id Cat Field -->
<div class="form-group">
    {!! Form::label('id_cat', 'Id Cat:') !!}
    <p>{!! $produit->id_cat !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $produit->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $produit->updated_at !!}</p>
</div>

