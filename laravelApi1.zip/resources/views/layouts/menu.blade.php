<li >
<a href="{!! route('categories.index')!!}"><i class="fa fa-edit"></i><span>Categories</span></a>
</li>

<li >
<a href="{!! route('produits.index')!!}"><i class="fa fa-edit"></i><span>Produits</span></a>
</li>