<!-- Nomcat Field -->
<div class="form-group">
    {!! Form::label('nomcat', 'Nomcat:') !!}
    <p>{!! $categorie->nomcat !!}</p>
</div>

<!-- Imagecat Field -->
<div class="form-group">
    {!! Form::label('imagecat', 'Imagecat:') !!}
    <p>{!! $categorie->imagecat !!}</p>
</div>

<!-- Description Field -->
<div class="form-group">
    {!! Form::label('description', 'Description:') !!}
    <p>{!! $categorie->description !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $categorie->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $categorie->updated_at !!}</p>
</div>

