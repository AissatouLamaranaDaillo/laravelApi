<!-- Nomprod Field -->
<div class="form-group">
    <?php echo Form::label('nomprod', 'Nomprod:'); ?>

    <p><?php echo $produit->nomprod; ?></p>
</div>

<!-- Imageprod Field -->
<div class="form-group">
    <?php echo Form::label('imageprod', 'Imageprod:'); ?>

    <p><?php echo $produit->imageprod; ?></p>
</div>

<!-- Prix Field -->
<div class="form-group">
    <?php echo Form::label('prix', 'Prix:'); ?>

    <p><?php echo $produit->prix; ?></p>
</div>

<!-- Quantite Field -->
<div class="form-group">
    <?php echo Form::label('quantite', 'Quantite:'); ?>

    <p><?php echo $produit->quantite; ?></p>
</div>

<!-- Id Cat Field -->
<div class="form-group">
    <?php echo Form::label('id_cat', 'Id Cat:'); ?>

    <p><?php echo $produit->id_cat; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $produit->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $produit->updated_at; ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\Commerce\laravelApi\resources\views/produits/show_fields.blade.php ENDPATH**/ ?>