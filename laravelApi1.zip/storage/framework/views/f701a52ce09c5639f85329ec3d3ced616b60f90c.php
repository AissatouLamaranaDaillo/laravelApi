<li >
<a href="<?php echo route('categories.index'); ?>"><i class="fa fa-edit"></i><span>Categories</span></a>
</li>

<li >
<a href="<?php echo route('produits.index'); ?>"><i class="fa fa-edit"></i><span>Produits</span></a>
</li><?php /**PATH C:\xampp\htdocs\Commerce\laravelApi\resources\views/layouts/menu.blade.php ENDPATH**/ ?>