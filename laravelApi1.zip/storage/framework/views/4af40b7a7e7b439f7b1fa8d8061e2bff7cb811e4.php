<!-- Nomcat Field -->
<div class="form-group">
    <?php echo Form::label('nomcat', 'Nomcat:'); ?>

    <p><?php echo $categorie->nomcat; ?></p>
</div>

<!-- Imagecat Field -->
<div class="form-group">
    <?php echo Form::label('imagecat', 'Imagecat:'); ?>

    <p><?php echo $categorie->imagecat; ?></p>
</div>

<!-- Description Field -->
<div class="form-group">
    <?php echo Form::label('description', 'Description:'); ?>

    <p><?php echo $categorie->description; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $categorie->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $categorie->updated_at; ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\Commerce\laravelApi\resources\views/categories/show_fields.blade.php ENDPATH**/ ?>