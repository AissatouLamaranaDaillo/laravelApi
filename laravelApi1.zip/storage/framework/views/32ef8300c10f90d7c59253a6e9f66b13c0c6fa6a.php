<div class="table-responsive">
    <table class="table" id="categories-table">
        <thead>
            <tr>
                <th>Nomcat</th>
        <th>Imagecat</th>
        <th>Description</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo $categorie->nomcat; ?></td>
           <td> <img src="<?php echo e('catImages/' . $categorie->imagecat); ?>" 
           alt=""  class="" height="50" witdh="50"></td>
            <td><?php echo $categorie->description; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['categories.destroy',  $categorie->id], 'method' => 'delete' ]); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('categories.show', [$categorie->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo route('categories.edit', [$categorie->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\Commerce\laravelApi\resources\views/categories/table.blade.php ENDPATH**/ ?>